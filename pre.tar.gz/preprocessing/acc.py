import codecs
import thulac


def com_acc(lines):
    act = []
    pred = []
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    corr = 0
    ner = 0
    b_ner = 'B_TRANS'
    i_ner = 'I_TRANS'
    e_ner = 'E_TRANS'

    for line in lines:
        if line == '\n':
            continue
        act.append(line.split('\t')[-2])
        pred.append(line.split('\t')[-1][:-1])

    for i in range(0, len(act)):
        if act[i] in [b_ner, i_ner, e_ner]:
            if pred[i] in [b_ner, i_ner, e_ner]:
                TP += 1
            else:
                FN += 1
        else:
            if pred[i] == 'O':
                TN += 1
            else:
                FP += 1
        if act[i] != 'O':
            if i == len(act) or act[i+1] == 'O':
            
                ner += 1
                if act[i] == pred[i]:
                    corr += 1

    print("acc: " + str(corr/ner))
    #print("recall: " + str(TP/(TP+FN)))
    #print("F1: " + str(2*TP/(2*TP+FP+FN)))


def extract_ner(lines):
    act = []
    pred = []
    corr = 0
    ner = 0
    b_ner = 'B_TRANS'
    i_ner = 'I_TRANS'
    e_ner = 'E_TRANS'

    for line in lines:
        if line == '\n':
            continue
        act.append(line.split('\t')[-2])
        pred.append(line.split('\t')[-1][:-1])

    i = 0
    while i < len(act):
        if act[i] != 'O':
            flag, i = dig(act, pred, i)
            ner += 1
            if flag:
                corr += 1
        i += 1
    print(corr/ner)


def dig(act, pred, i):
    flag = True
    while True:
        if act[i] == 'O':
            if pred[i] == 'O':
                return flag, i
            else:
                return False, i
        else:
            if act[i] == pred[i]:
                i += 1
            else:
                i += 1
                flag = False


if __name__ == '__main__':
    # with codecs.open('./MSRA_train.txt', 'rb', encoding='utf-8') as file:
    #     new_line_lst = file.readlines()
    #
    # cut(new_line_lst)
    # with codecs.open('C:/Users/suning/Desktop/新项目/我的工作/CRF/src/main/resources/MSRA_train.txt', 'rb', encoding='utf-8') as file:
    #     lines = file.readlines()
    # add_DRP(lines)
    # # add_NER_tag()
    #
    with codecs.open('./output.txt', 'rb', encoding='utf-8') as res_file:
        lines = res_file.readlines()
    extract_ner(lines)
