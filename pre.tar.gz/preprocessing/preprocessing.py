import codecs
import thulac


def cut(new_line_lst):
    with codecs.open('./MSRA_test_new.txt', 'w', encoding='utf-8') as tag_file:
    
        sentence = ''
        word_tags = []
        tmp = []
        for new_line in new_line_lst:

            sentence += new_line.split('\t')[0]
            if new_line != '\n':
                tmp.append(new_line.split('\t')[1])
            else:
                word_tags.append(tmp)
                tmp = []
        
        thu = thulac.thulac()
        sentence_lst = sentence.split('\n')
        for i, line in enumerate(sentence_lst):
            sen_len = len(line)
            raw_text = thu.cut(line.strip(), text=True)
            word_lst = raw_text.split(' ')
        
            num = 0
            res = ''
            for item in word_lst:
                word, flag = item.split('_')
                t = 0
                for s in word:
                    res += s+'\t'+str(int(num/sen_len*4)+1)+'\t'+flag+'\t'+str(t)+'\t'+word_tags[i][num]
                    num += 1
                    t += 1
            res += '\n'
            print(i)

            tag_file.write(res)
    return res[:-1]


def com_acc(lines):
    act = []
    pred = []
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    corr = 0
    b_ner = 'B_TRANS'
    i_ner = 'I_TRANS'
    e_ner = 'E_TRANS'

    for line in lines:
        if line == '\n':
            continue
        act.append(line.split('\t')[-2])
        pred.append(line.split('\t')[-1][:-1])

    for i in range(0, len(act)):
        if act[i] in [b_ner, i_ner, e_ner]:
            if pred[i] in [b_ner, i_ner, e_ner]:
                TP += 1
            else:
                FN += 1
        else:
            if pred[i] == 'O':
                TN += 1
            else:
                FP += 1
        if act[i] == pred[i]:
            corr += 1

    print("acc: " + str(corr/len(act)))
    print("recall: " + str(TP/(TP+FN)))
    print("F1: " + str(2*TP/(2*TP+FP+FN)))


if __name__ == '__main__':
    with codecs.open('./MSRA_test.txt', 'rb', encoding='utf-8') as file:
        new_line_lst = file.readlines()

    cut(new_line_lst)

